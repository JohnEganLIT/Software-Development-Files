﻿namespace OrderManagement
{
    interface IOrdersDB
    {
        void Add(IOrder order);
    }
}
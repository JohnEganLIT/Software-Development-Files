function toggleInput1() //Toggles input on user, email, and saveBtn1 in account.php.
{
    document.getElementById("user").disabled = false;
	document.getElementById("email").disabled = false;
	document.getElementById("saveBtn1").disabled = false;
}

function toggleInput2() //Togges input on address fields and saveBtn2 in account.php.
{
    document.getElementById("address1").disabled = false;
	document.getElementById("address2").disabled = false;
	document.getElementById("town").disabled = false;
	document.getElementById("county").disabled = false;
	document.getElementById("saveBtn2").disabled = false;
}

